import { useState, useMemo, lazy } from 'react'
import { motion } from 'framer-motion'
import { useTranslation } from 'react-i18next'
import { CertificateCard } from '../components/ui/CertificateCard'
import { Icon } from '../components/ui/Icon'
import { certificates, certificateCategories } from '../data/certificates'
import type { Certificate } from '../types'

const CertificateModal = lazy(() =>
  import('../components/ui/CertificateModal').then((m) => ({ default: m.CertificateModal }))
)

const ScrollReveal = lazy(() =>
  import('../components/ui/ScrollReveal').then((m) => ({ default: m.ScrollReveal }))
)

const categoryLabels: Record<string, { en: string; ar: string }> = {
  all: { en: 'All Documents', ar: 'كل المستندات' },
  tax: { en: 'Tax Documents', ar: 'المستندات الضريبية' },
  registration: { en: 'Commercial Registration', ar: 'السجل التجاري' },
  membership: { en: 'Memberships', ar: 'العضويات' },
  legal: { en: 'Legal Agreements', ar: 'الاتفاقيات القانونية' },
}

export function CertificatesPage() {
  const { t, i18n } = useTranslation()
  const isArabic = i18n.language === 'ar'
  const [activeCategory, setActiveCategory] = useState('all')
  const [searchQuery, setSearchQuery] = useState('')
  const [selected, setSelected] = useState<Certificate | null>(null)
  const items = useMemo(() => [...certificates].sort((a, b) => a.order - b.order), [])

  const filtered = useMemo(() => {
    let result = items

    if (activeCategory !== 'all') {
      result = result.filter((certificate) => certificate.category === activeCategory)
    }

    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase()
      result = result.filter((certificate) =>
        [
          certificate.title,
          certificate.titleAr,
          certificate.organization,
          certificate.organizationAr,
          certificate.description,
          certificate.descriptionAr,
          certificate.referenceNumber,
          certificate.category,
        ]
          .filter(Boolean)
          .some((value) => String(value).toLowerCase().includes(query))
      )
    }

    return result
  }, [activeCategory, searchQuery, items])

  const handlePrev = () => {
    const index = filtered.findIndex((certificate) => certificate.id === selected?.id)
    if (index > 0) setSelected(filtered[index - 1])
    else setSelected(filtered[filtered.length - 1])
  }

  const handleNext = () => {
    const index = filtered.findIndex((certificate) => certificate.id === selected?.id)
    if (index < filtered.length - 1) setSelected(filtered[index + 1])
    else setSelected(filtered[0])
  }

  return (
    <div className="pt-28 pb-24">
      <div
        className="relative py-20 md:py-28 bg-cover bg-center mb-16"
        style={{
          backgroundImage:
            'url(https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=1920&q=80)',
        }}
      >
        <div className="absolute inset-0 bg-[#0D2B45]/90" />
        <div className="content-container relative z-10 text-center">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-block text-accent font-semibold text-sm tracking-[0.2em] uppercase mb-4"
          >
            {isArabic ? 'الوثائق الرسمية للشركة' : 'Official Company Documents'}
          </motion.span>
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 }}
            className="text-3xl md:text-5xl font-extrabold text-white mb-4"
          >
            {t('certificates.pageTitle')}
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="text-white/70 text-lg max-w-3xl mx-auto"
          >
            {isArabic
              ? 'نسخ من المستندات الرسمية المقدمة ضمن ملف شركة إم إم للمقاولات والتوريدات، وتشمل التسجيلات الضريبية والسجل التجاري وعضوية اتحاد المقاولين والاتفاقيات القانونية.'
              : 'Official documents supplied in the MM Contracting & Supplying Co. profile, including tax registrations, commercial registration, contractor federation membership and legal agreements.'}
          </motion.p>
        </div>
      </div>

      <div className="content-container">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-10">
          <div className="flex flex-wrap gap-2">
            {certificateCategories.map((category) => (
              <button
                key={category.id}
                onClick={() => setActiveCategory(category.id)}
                className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-300 ${
                  activeCategory === category.id
                    ? 'bg-primary text-white'
                    : 'bg-surface text-body hover:bg-primary/10 hover:text-primary border border-border'
                }`}
                aria-pressed={activeCategory === category.id}
              >
                {categoryLabels[category.id]?.[isArabic ? 'ar' : 'en'] ?? category.label}
              </button>
            ))}
          </div>

          <div className="relative w-full md:w-72">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t('certificates.searchPlaceholder')}
              className="w-full ps-10 pe-4 py-2.5 rounded-lg border border-border bg-white text-sm text-title focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
              aria-label={t('certificates.searchAria')}
            />
            <Icon
              name="Search"
              size={16}
              className="absolute start-3 top-1/2 -translate-y-1/2 text-muted"
            />
          </div>
        </div>

        {filtered.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-muted text-lg">{t('certificates.noResults')}</p>
          </div>
        ) : (
          <motion.div
            layout
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {filtered.map((certificate, index) => (
              <ScrollReveal key={certificate.id} delay={index * 0.05}>
                <div onClick={() => setSelected(certificate)} className="cursor-pointer h-full">
                  <CertificateCard certificate={certificate} onView={setSelected} />
                </div>
              </ScrollReveal>
            ))}
          </motion.div>
        )}
      </div>

      {selected && (
        <CertificateModal
          certificate={selected}
          onClose={() => setSelected(null)}
          onPrev={handlePrev}
          onNext={handleNext}
          hasPrev={filtered.length > 1}
          hasNext={filtered.length > 1}
        />
      )}
    </div>
  )
}
